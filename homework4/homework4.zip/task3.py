a = '*'
b = 8
c = b
for i in range(b):
    print(a * c)
    c -= 1


a = '*'
b = 8
c = 0
for i in range(b):
    print(a * c)
    c += 1
